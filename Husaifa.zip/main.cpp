#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <ctime>
#include <limits>

using namespace std;

/* ---------- Utility Functions ---------- */

static void flushLine() {
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

static string readLine(const string &prompt) {
    cout << prompt;
    string s;
    getline(cin, s);
    return s;
}

static int readInt(const string &prompt) {
    cout << prompt;
    int v;
    while (!(cin >> v)) {
        cin.clear();
        flushLine();
        cout << "Invalid input. Try again: ";
    }
    flushLine();
    return v;
}

/* ---------- Location Class ---------- */

class Location {
    time_t dateSet;
    string dateKnownLocation;

public:
    Location()
        : dateSet(time(nullptr)), dateKnownLocation("") {}

    Location(string loc)
        : dateSet(time(nullptr)), dateKnownLocation(loc) {}

    string getLocation() const {
        return dateKnownLocation;
    }
};

/* ---------- Item Class ---------- */

class Item {
    string itemId;
    string name;
    string category;
    string description;
    time_t dateReported;
    string location;

public:
    Item()
        : itemId(""), name(""), category(""),
          description(""), dateReported(time(nullptr)), location("") {}

    Item(string id, string n, string cat, string desc, string loc)
        : itemId(id), name(n), category(cat),
          description(desc), dateReported(time(nullptr)), location(loc) {}

    string getId() const { return itemId; }
    string getName() const { return name; }
    string getCategory() const { return category; }
    string getDescription() const { return description; }
    string getLocation() const { return location; }

    void display() const {
        cout << "\n[Item]"
             << "\n ID: " << itemId
             << "\n Name: " << name
             << "\n Category: " << category
             << "\n Description: " << description
             << "\n Location: " << location << "\n";
    }
};

/* ---------- Claim Class ---------- */

class Claim {
    string claimId;
    string itemId;
    string claimedByUserId;
    time_t dateClaimed;
    string verificationDetails;
    string claimStatus;

public:
    Claim()
        : claimId(""), itemId(""), claimedByUserId(""),
          dateClaimed(time(nullptr)), verificationDetails(""),
          claimStatus("pending") {}

    Claim(string cId, string iId, string userId, string details)
        : claimId(cId), itemId(iId), claimedByUserId(userId),
          dateClaimed(time(nullptr)), verificationDetails(details),
          claimStatus("pending") {}

    string getClaimId() const { return claimId; }
    string getItemId() const { return itemId; }
    string getStatus() const { return claimStatus; }

    void setStatus(string status) {
        claimStatus = status;
    }

    void display() const {
        cout << "\n[Claim]"
             << "\n Claim ID: " << claimId
             << "\n Item ID: " << itemId
             << "\n Claimed By: " << claimedByUserId
             << "\n Status: " << claimStatus
             << "\n Verification: " << verificationDetails << "\n";
    }
};

/* ---------- User Class ---------- */

class User {
    string userId;
    string name;
    string email;
    string phoneNumber;
    string universeId;
    string role;

public:
    User()
        : userId(""), name(""), email(""),
          phoneNumber(""), universeId(""), role("") {}

    User(string id, string n, string e, string phone, string r)
        : userId(id), name(n), email(e),
          phoneNumber(phone), universeId(id), role(r) {}

    string getUserId() const { return userId; }
    string getName() const { return name; }
    string getRole() const { return role; }

    void registerUser() const {
        cout << "\n>> User '" << name << "' registered successfully.\n";
    }

    void login() const {
        cout << "\n>> User '" << name << "' logged in.\n";
    }

    void reportLostItem(const string &itemName) const {
        cout << "\n>> " << name << " reported lost item: "
             << itemName << "\n";
    }

    void display() const {
        cout << "\n[User]"
             << "\n ID: " << userId
             << "\n Name: " << name
             << "\n Email: " << email
             << "\n Phone: " << phoneNumber
             << "\n Role: " << role << "\n";
    }
};

/* ---------- FoundItem Class ---------- */

class FoundItem {
    string foundId;
    time_t dateFound;
    string foundLocation;
    string storageLocation;
    string foundByUserId;

public:
    FoundItem()
        : foundId(""), dateFound(time(nullptr)),
          foundLocation(""), storageLocation(""),
          foundByUserId("") {}

    FoundItem(string fId, string fLoc, string sLoc, string userId)
        : foundId(fId), dateFound(time(nullptr)),
          foundLocation(fLoc), storageLocation(sLoc),
          foundByUserId(userId) {}

    void display() const {
        cout << "\n[Found Item]"
             << "\n ID: " << foundId
             << "\n Found At: " << foundLocation
             << "\n Storage Location: " << storageLocation
             << "\n Found By: " << foundByUserId << "\n";
    }
};

/* ---------- SystemAdmin Class ---------- */

class SystemAdmin {
    string adminId;
    string name;

public:
    SystemAdmin()
        : adminId(""), name("") {}

    SystemAdmin(string id, string n)
        : adminId(id), name(n) {}

    void verifyClaim(Claim &claim) const {
        cout << "\n>> Admin '" << name
             << "' verifying claim: "
             << claim.getClaimId() << "\n";
        claim.setStatus("verified");
    }

    void generateReports() const {
        cout << "\n>> Admin '" << name
             << "' generated system reports.\n";
    }

    void display() const {
        cout << "\n[System Admin]"
             << "\n ID: " << adminId
             << "\n Name: " << name << "\n";
    }
};

/* ---------- Notification Class ---------- */

class Notification {
    string notificationId;
    string userId;
    string message;
    time_t timestamp;
    string status;

public:
    Notification()
        : notificationId(""), userId(""),
          message(""), timestamp(time(nullptr)),
          status("unread") {}

    Notification(string nId, string uId, string msg)
        : notificationId(nId), userId(uId),
          message(msg), timestamp(time(nullptr)),
          status("unread") {}

    void markAsRead() {
        status = "read";
    }

    void display() const {
        cout << "\n[Notification]"
             << "\n ID: " << notificationId
             << "\n To User: " << userId
             << "\n Message: " << message
             << "\n Status: " << status << "\n";
    }
};

/* ---------- Main Function ---------- */

int main() {
    cout << "\n========== LOST & FOUND SYSTEM ==========\n";

    // Admin Setup
    string adminId = readLine("Enter Admin ID: ");
    string adminName = readLine("Enter Admin Name: ");
    SystemAdmin admin(adminId, adminName);
    admin.display();

    // User Setup
    string userId = readLine("\nEnter User ID: ");
    string userName = readLine("Enter User Name: ");
    string userEmail = readLine("Enter User Email: ");
    string userPhone = readLine("Enter User Phone: ");

    User user(userId, userName, userEmail, userPhone, "user");
    user.display();
    user.registerUser();
    user.login();

    // Lost Item
    string itemName = readLine("\nEnter Lost Item Name: ");
    user.reportLostItem(itemName);

    string itemId = readLine("Enter Item ID: ");
    string category = readLine("Enter Category: ");
    string description = readLine("Enter Description: ");
    string lastLocation = readLine("Enter Last Known Location: ");

    Item lostItem(itemId, itemName, category, description, lastLocation);
    lostItem.display();

    // Found Item
    string foundItemId = readLine("\nEnter Found Item ID: ");
    string foundLocation = readLine("Enter Found Location: ");
    string storageLocation = readLine("Enter Storage Location: ");
    string foundByUserId = readLine("Enter Finder User ID: ");

    FoundItem foundItem(foundItemId, foundLocation, storageLocation, foundByUserId);
    foundItem.display();

    // Claim
    string claimId = readLine("\nEnter Claim ID: ");
    string verificationDetails = readLine("Enter Verification Details: ");

    Claim claim(claimId, lostItem.getId(), user.getUserId(), verificationDetails);
    claim.display();

    // Verification
    admin.verifyClaim(claim);
    claim.display();

    // Notification
    string notifId = readLine("\nEnter Notification ID: ");
    Notification notification(
        notifId,
        user.getUserId(),
        "Your lost item has been found and verified!"
    );

    notification.display();
    notification.markAsRead();
    notification.display();

    // Reports
    admin.generateReports();

    cout << "\n========== END OF SYSTEM ==========\n";
    return 0;
}
